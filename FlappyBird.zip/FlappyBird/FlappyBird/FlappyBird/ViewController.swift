//
//  ViewController.swift
//  FlappyBird
//
//  Created by PATRICIA S SIQUEIRA on 10/10/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

